<template>
  <div class="MovieDetailPage">
    <MovieInfo />
    <MovieReview />
  </div>
</template>

<script>
import MovieInfo from "@/components/MovieInfo.vue";
import MovieReview from "@/components/MovieReview.vue";

export default {
  name: "MovieDetail",
  components: {
    MovieInfo,
    MovieReview,
  },
  data() {
    return {
      movieId: null,
    };
  },
  created() {
    this.movieId = this.$route.params.id;
  },
};
</script>

<style scoped>
h1 {
  color: white;
}
.MovieDetailPage {
  padding: 80px;
  display: flex;
}
</style>
