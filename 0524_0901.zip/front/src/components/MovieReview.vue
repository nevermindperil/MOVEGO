<template>
  <div class="MovieReviewContainer">
    <h1>영화리뷰</h1>

    <MovieReviewList />
  </div>
</template>

<script>
import MovieReviewList from "@/components/MovieReviewList.vue";

export default {
  name: "MovieReview",
  components: {
    MovieReviewList,
  },

  mounted() {},
  computed: {},

  methods: {},

  // ...
};
</script>

<style>
.MovieReviewContainer {
  height: fit-content;
  background-color: #fff;
  width: 36%;
  padding: 25px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  border-radius: 8px;
}
</style>
