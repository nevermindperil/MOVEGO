<template>
  <div class="MovieReviewItemContainer">
    <h2>리뷰 리스트</h2>
    <ul>
      <MovieReviewItem />
    </ul>
  </div>
</template>
<script>
import MovieReviewItem from "@/components/MovieReviewItem.vue";

export default {
  name: "MovieReviewList",
  components: {
    MovieReviewItem,
  },
  computed: {},
};
</script>
<style scoped></style>
