<template>
  <div class="MovieReviewItemContainer">
    <p>{{ review.content }}</p>
  </div>
</template>

<script>
export default {
  name: "MovieReviewItem",

  methods: {},
};
</script>

<style scoped>
.MovieReviewItemContainer {
  border: 1px solid #ddd;
  padding: 10px;
  margin-bottom: 10px;
}
</style>
